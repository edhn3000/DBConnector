// CodeGear C++Builder
// Copyright (c) 1995, 2011 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sRegisterIt.pas' rev: 23.00 (Win32)

#ifndef SregisteritHPP
#define SregisteritHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.Classes.hpp>	// Pascal unit
#include <sScrollBar.hpp>	// Pascal unit
#include <sLabel.hpp>	// Pascal unit
#include <sButton.hpp>	// Pascal unit
#include <sBitBtn.hpp>	// Pascal unit
#include <sSpeedButton.hpp>	// Pascal unit
#include <sPanel.hpp>	// Pascal unit
#include <sListBox.hpp>	// Pascal unit
#include <acTitleBar.hpp>	// Pascal unit
#include <sHintManager.hpp>	// Pascal unit
#include <sToolBar.hpp>	// Pascal unit
#include <sColorSelect.hpp>	// Pascal unit
#include <sDialogs.hpp>	// Pascal unit
#include <sCurrencyEdit.hpp>	// Pascal unit
#include <sSpinEdit.hpp>	// Pascal unit
#include <sRadioButton.hpp>	// Pascal unit
#include <sComboEdit.hpp>	// Pascal unit
#include <sPageControl.hpp>	// Pascal unit
#include <sCurrEdit.hpp>	// Pascal unit
#include <sTooledit.hpp>	// Pascal unit
#include <sMonthCalendar.hpp>	// Pascal unit
#include <sBevel.hpp>	// Pascal unit
#include <sGroupBox.hpp>	// Pascal unit
#include <sStatusBar.hpp>	// Pascal unit
#include <sTrackBar.hpp>	// Pascal unit
#include <sCalculator.hpp>	// Pascal unit
#include <sMaskEdit.hpp>	// Pascal unit
#include <sComboBoxes.hpp>	// Pascal unit
#include <sSplitter.hpp>	// Pascal unit
#include <sTabControl.hpp>	// Pascal unit
#include <sFontCtrls.hpp>	// Pascal unit
#include <sScrollBox.hpp>	// Pascal unit
#include <sRichEdit.hpp>	// Pascal unit
#include <sFileCtrl.hpp>	// Pascal unit
#include <sTreeView.hpp>	// Pascal unit
#include <sFrameAdapter.hpp>	// Pascal unit
#include <sUpDown.hpp>	// Pascal unit
#include <sFrameBar.hpp>	// Pascal unit
#include <acShellCtrls.hpp>	// Pascal unit
#include <acCoolBar.hpp>	// Pascal unit
#include <acProgressBar.hpp>	// Pascal unit
#include <acNoteBook.hpp>	// Pascal unit
#include <acAlphaHints.hpp>	// Pascal unit
#include <acHeaderControl.hpp>	// Pascal unit
#include <acMagn.hpp>	// Pascal unit
#include <sListView.hpp>	// Pascal unit
#include <sGauge.hpp>	// Pascal unit
#include <sEdit.hpp>	// Pascal unit
#include <sSkinManager.hpp>	// Pascal unit
#include <sSkinProvider.hpp>	// Pascal unit
#include <sComboBox.hpp>	// Pascal unit
#include <sCheckBox.hpp>	// Pascal unit
#include <acAlphaImageList.hpp>	// Pascal unit
#include <sMemo.hpp>	// Pascal unit
#include <sCheckListBox.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sregisterit
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Sregisterit */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_SREGISTERIT)
using namespace Sregisterit;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SregisteritHPP
