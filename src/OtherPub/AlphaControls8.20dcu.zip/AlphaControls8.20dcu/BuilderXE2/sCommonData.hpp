// CodeGear C++Builder
// Copyright (c) 1995, 2011 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sCommonData.pas' rev: 23.00 (Win32)

#ifndef ScommondataHPP
#define ScommondataHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Winapi.Windows.hpp>	// Pascal unit
#include <Vcl.Graphics.hpp>	// Pascal unit
#include <System.Classes.hpp>	// Pascal unit
#include <Vcl.Controls.hpp>	// Pascal unit
#include <System.SysUtils.hpp>	// Pascal unit
#include <Vcl.StdCtrls.hpp>	// Pascal unit
#include <Vcl.Dialogs.hpp>	// Pascal unit
#include <sSkinManager.hpp>	// Pascal unit
#include <acntUtils.hpp>	// Pascal unit
#include <System.Types.hpp>	// Pascal unit
#include <Vcl.Forms.hpp>	// Pascal unit
#include <Winapi.Messages.hpp>	// Pascal unit
#include <sConst.hpp>	// Pascal unit
#include <Vcl.ExtCtrls.hpp>	// Pascal unit
#include <System.IniFiles.hpp>	// Pascal unit
#include <sLabel.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Scommondata
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsCommonData;
#pragma pack(push,4)
class PASCALIMPLEMENTATION TsCommonData : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	System::UnicodeString FSkinSection;
	bool FCustomFont;
	bool FCustomColor;
	int FUpdateCount;
	void __fastcall SetSkinSection(const System::UnicodeString Value);
	bool __fastcall GetUpdating(void);
	void __fastcall SetUpdating(const bool Value);
	void __fastcall SetCustomColor(const bool Value);
	void __fastcall SetCustomFont(const bool Value);
	Sskinmanager::TsSkinManager* __fastcall GetSkinManager(void);
	void __fastcall SetSkinManager(const Sskinmanager::TsSkinManager* Value);
	void __fastcall SetHUEOffset(const int Value);
	void __fastcall SetSaturation(const int Value);
	
public:
	int FHUEOffset;
	int FSaturation;
	int GlowID;
	bool FUpdating;
	Sskinmanager::TsSkinManager* FSkinManager;
	int BorderIndex;
	int SkinIndex;
	int Texture;
	int HotTexture;
	void *GraphControl;
	bool UrgentPainting;
	bool BGChanged;
	bool HalfVisible;
	Vcl::Controls::TControl* FOwnerControl;
	System::TObject* FOwnerObject;
	Vcl::Graphics::TBitmap* FCacheBmp;
	HRGN FRegion;
	int COC;
	bool FFocused;
	bool FMouseAbove;
	System::Word CtrlSkinState;
	System::Word BGType;
	HDC PrintDC;
	#pragma pack(push,8)
	System::Types::TRect InvalidRectH;
	#pragma pack(pop)
	#pragma pack(push,8)
	System::Types::TRect InvalidRectV;
	#pragma pack(pop)
	__property bool Updating = {read=GetUpdating, write=SetUpdating, default=0};
	__fastcall TsCommonData(System::TObject* AOwner, bool CreateCacheBmp);
	__fastcall virtual ~TsCommonData(void);
	void __fastcall UpdateIndexes(void);
	void __fastcall Loaded(void);
	bool __fastcall RepaintIfMoved(void);
	bool __fastcall ManagerStored(void);
	void __fastcall BeginUpdate(void);
	void __fastcall EndUpdate(bool Repaint = false);
	void __fastcall Invalidate(bool UpdateNow = false);
	bool __fastcall Skinned(bool CheckSkinActive = false);
	__property int HUEOffset = {read=FHUEOffset, write=SetHUEOffset, default=0};
	__property int Saturation = {read=FSaturation, write=SetSaturation, default=0};
	
__published:
	__property bool CustomColor = {read=FCustomColor, write=SetCustomColor, default=0};
	__property bool CustomFont = {read=FCustomFont, write=SetCustomFont, default=0};
	__property Sskinmanager::TsSkinManager* SkinManager = {read=GetSkinManager, write=SetSkinManager, stored=ManagerStored};
	__property System::UnicodeString SkinSection = {read=FSkinSection, write=SetSkinSection};
};

#pragma pack(pop)

class DELPHICLASS TsCtrlSkinData;
#pragma pack(push,4)
class PASCALIMPLEMENTATION TsCtrlSkinData : public TsCommonData
{
	typedef TsCommonData inherited;
	
__published:
	__property HUEOffset = {default=0};
	__property Saturation = {default=0};
public:
	/* TsCommonData.Create */ inline __fastcall TsCtrlSkinData(System::TObject* AOwner, bool CreateCacheBmp) : TsCommonData(AOwner, CreateCacheBmp) { }
	/* TsCommonData.Destroy */ inline __fastcall virtual ~TsCtrlSkinData(void) { }
	
};

#pragma pack(pop)

class DELPHICLASS TsBoundLabel;
#pragma pack(push,4)
class PASCALIMPLEMENTATION TsBoundLabel : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FMaxWidth;
	System::UnicodeString FText;
	Sconst::TsCaptionLayout FLayout;
	Vcl::Graphics::TFont* FFont;
	int FIndent;
	void __fastcall SetActive(const bool Value);
	void __fastcall SetLayout(const Sconst::TsCaptionLayout Value);
	void __fastcall SetMaxWidth(const int Value);
	void __fastcall SetText(const System::UnicodeString Value);
	void __fastcall SetFont(const Vcl::Graphics::TFont* Value);
	void __fastcall SetIndent(const int Value);
	Vcl::Graphics::TFont* __fastcall GetFont(void);
	void __fastcall UpdateAlignment(void);
	bool __fastcall GetUseSkin(void);
	void __fastcall SetUseSkin(const bool Value);
	
public:
	bool FActive;
	Slabel::TsEditLabel* FTheLabel;
	TsCommonData* FCommonData;
	void __fastcall AlignLabel(void);
	__fastcall TsBoundLabel(System::TObject* AOwner, TsCommonData* CommonData);
	__fastcall virtual ~TsBoundLabel(void);
	
__published:
	__property bool Active = {read=FActive, write=SetActive, default=0};
	__property System::UnicodeString Caption = {read=FText, write=SetText};
	__property int Indent = {read=FIndent, write=SetIndent, nodefault};
	__property Vcl::Graphics::TFont* Font = {read=GetFont, write=SetFont};
	__property Sconst::TsCaptionLayout Layout = {read=FLayout, write=SetLayout, nodefault};
	__property int MaxWidth = {read=FMaxWidth, write=SetMaxWidth, nodefault};
	__property bool UseSkinColor = {read=GetUseSkin, write=SetUseSkin, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Sconst::TsColor C1;
extern PACKAGE Sconst::TsColor C2;
extern PACKAGE bool RestrictDrawing;
extern PACKAGE bool __fastcall IsCached(TsCommonData* SkinData);
extern PACKAGE bool __fastcall InUpdating(TsCommonData* SkinData, bool Reset = false);
extern PACKAGE int __fastcall IsCacheRequired(TsCommonData* SkinData);
extern PACKAGE void __fastcall InitBGInfo(const TsCommonData* SkinData, const Sconst::PacBGInfo PBGInfo, const int State, unsigned Handle = (unsigned)(0x0));
extern PACKAGE System::Uitypes::TColor __fastcall GetBGColor(const TsCommonData* SkinData, const int State, unsigned Handle = (unsigned)(0x0));
extern PACKAGE int __fastcall GetFontIndex(const Vcl::Controls::TControl* Ctrl, const int DefSkinIndex, const Sskinmanager::TsSkinManager* SkinManager, int State = 0x0);
extern PACKAGE bool __fastcall ParentTextured(const TsCommonData* SkinData);
extern PACKAGE bool __fastcall FullRepaintOnly(const TsCommonData* SkinData, Vcl::Stdctrls::TScrollStyle ResizeDirection);
extern PACKAGE void __fastcall ShowGlowingIfNeeded(const TsCommonData* SkinData, bool Clicked = false, HWND CtrlHandle = (HWND)(0x0));
extern PACKAGE void __fastcall InitCacheBmp(TsCommonData* SkinData);
extern PACKAGE int __fastcall SkinBorderMaxWidth(TsCommonData* SkinData);
extern PACKAGE Sconst::TCacheInfo __fastcall GetParentCache(TsCommonData* SkinData);
extern PACKAGE Sconst::TCacheInfo __fastcall GetParentCacheHwnd(HWND cHwnd);
extern PACKAGE void __fastcall UpdateData(TsCommonData* SkinData);
extern PACKAGE void __fastcall UpdateSkinState(const TsCommonData* SkinData, bool UpdateChildren = true);
extern PACKAGE bool __fastcall ControlIsActive(TsCommonData* SkinData);
extern PACKAGE bool __fastcall CommonMessage(Winapi::Messages::TMessage &Message, TsCommonData* SkinData);
extern PACKAGE bool __fastcall CommonWndProc(Winapi::Messages::TMessage &Message, TsCommonData* SkinData);
extern PACKAGE void __fastcall CopyWinControlCache(Vcl::Controls::TWinControl* Control, TsCommonData* SkinData, const System::Types::TRect &SrcRect, const System::Types::TRect &DstRect, HDC DstDC, bool UpdateCorners, int OffsetX = 0x0, int OffsetY = 0x0)/* overload */;
extern PACKAGE void __fastcall CopyHwndCache(unsigned hwnd, TsCommonData* SkinData, const System::Types::TRect &SrcRect, const System::Types::TRect &DstRect, HDC DstDC, bool UpdateCorners, int OffsetX = 0x0, int OffsetY = 0x0)/* overload */;

}	/* namespace Scommondata */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_SCOMMONDATA)
using namespace Scommondata;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ScommondataHPP
