// CodeGear C++Builder
// Copyright (c) 1995, 2011 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sVclUtils.pas' rev: 23.00 (Win32)

#ifndef SvclutilsHPP
#define SvclutilsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.Classes.hpp>	// Pascal unit
#include <Vcl.Controls.hpp>	// Pascal unit
#include <System.SysUtils.hpp>	// Pascal unit
#include <Vcl.StdCtrls.hpp>	// Pascal unit
#include <Winapi.Windows.hpp>	// Pascal unit
#include <Vcl.Dialogs.hpp>	// Pascal unit
#include <Vcl.Graphics.hpp>	// Pascal unit
#include <Vcl.Forms.hpp>	// Pascal unit
#include <Winapi.Messages.hpp>	// Pascal unit
#include <Vcl.ExtCtrls.hpp>	// Pascal unit
#include <sSkinProvider.hpp>	// Pascal unit
#include <acSBUtils.hpp>	// Pascal unit
#include <Vcl.ComCtrls.hpp>	// Pascal unit
#include <sConst.hpp>	// Pascal unit
#include <Vcl.Menus.hpp>	// Pascal unit
#include <System.IniFiles.hpp>	// Pascal unit
#include <System.Win.Registry.hpp>	// Pascal unit
#include <acntUtils.hpp>	// Pascal unit
#include <sCommonData.hpp>	// Pascal unit
#include <acDials.hpp>	// Pascal unit
#include <acThdTimer.hpp>	// Pascal unit
#include <System.Types.hpp>	// Pascal unit
#include <sEdit.hpp>	// Pascal unit
#include <sMemo.hpp>	// Pascal unit
#include <sComboBox.hpp>	// Pascal unit
#include <sCurrEdit.hpp>	// Pascal unit
#include <sDateUtils.hpp>	// Pascal unit
#include <sCustomComboEdit.hpp>	// Pascal unit
#include <sRadioButton.hpp>	// Pascal unit
#include <sCheckBox.hpp>	// Pascal unit
#include <sGraphUtils.hpp>	// Pascal unit
#include <Vcl.Buttons.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Svclutils
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TOutputWindow;
class PASCALIMPLEMENTATION TOutputWindow : public Vcl::Controls::TCustomControl
{
	typedef Vcl::Controls::TCustomControl inherited;
	
private:
	HIDESBASE MESSAGE void __fastcall WMEraseBkgnd(Winapi::Messages::TWMEraseBkgnd &Message);
	HIDESBASE MESSAGE void __fastcall WMNCPaint(Winapi::Messages::TWMEraseBkgnd &Message);
	
protected:
	virtual void __fastcall CreateParams(Vcl::Controls::TCreateParams &Params);
	
public:
	__fastcall virtual TOutputWindow(System::Classes::TComponent* AOwner);
	__property Canvas;
public:
	/* TCustomControl.Destroy */ inline __fastcall virtual ~TOutputWindow(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TOutputWindow(HWND ParentWindow) : Vcl::Controls::TCustomControl(ParentWindow) { }
	
};


class DELPHICLASS TacHideTimer;
class PASCALIMPLEMENTATION TacHideTimer : public Acthdtimer::TacThreadedTimer
{
	typedef Acthdtimer::TacThreadedTimer inherited;
	
public:
	Acdials::TacDialogWnd* Dlg;
	unsigned ParentWnd;
	HDC DC;
	Vcl::Forms::TForm* Form;
	System::Types::TSize FBmpSize;
	System::Types::TPoint FBmpTopLeft;
	_BLENDFUNCTION FBlend;
	double dx;
	double dy;
	double l;
	double t;
	double r;
	double b;
	int StartBlendValue;
	int i;
	int StepCount;
	Sconst::TacAnimType AnimType;
	int DelayValue;
	bool EventCalled;
	double Trans;
	double p;
	Vcl::Graphics::TBitmap* SrcBmp;
	Vcl::Graphics::TBitmap* DstBmp;
	void __fastcall Anim_Init(void);
	void __fastcall CallEvent(void);
	void __fastcall Anim_DoNext(void);
	void __fastcall Anim_GoToNext(void);
	void __fastcall OnTimerProc(System::TObject* Sender);
	__fastcall virtual TacHideTimer(System::Classes::TComponent* AOwner);
	__fastcall virtual ~TacHideTimer(void);
public:
	/* TacThreadedTimer.CreateOwned */ inline __fastcall virtual TacHideTimer(System::Classes::TComponent* AOwner, bool ChangeEvent) : Acthdtimer::TacThreadedTimer(AOwner, ChangeEvent) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::StaticArray<int, 3> AlignToInt;
extern PACKAGE TOutputWindow* ow;
extern PACKAGE bool InAnimationProcess;
extern PACKAGE bool acGraphPainting;
extern PACKAGE unsigned uxthemeLib;
extern PACKAGE HRESULT __stdcall (*Ac_SetWindowTheme)(HWND hwnd, System::WideChar * pszSubAppName, System::WideChar * pszSubIdList);
extern PACKAGE TacHideTimer* acHideTimer;
extern PACKAGE System::Types::TPoint __fastcall acMousePos(void);
extern PACKAGE bool __fastcall LeftToRight(Vcl::Controls::TControl* Control, bool NormalAlignment = true);
extern PACKAGE void __fastcall AddToAdapter(Vcl::Controls::TWinControl* Frame);
extern PACKAGE void __fastcall BroadCastMsg(HWND Ctrl, const Winapi::Messages::TMessage &Message);
extern PACKAGE void __fastcall SkinPaintTo(const Vcl::Graphics::TBitmap* Bmp, const Vcl::Controls::TControl* Ctrl, int Left = 0x0, int Top = 0x0, System::Classes::TComponent* SkinProvider = (System::Classes::TComponent*)(0x0));
extern PACKAGE void __fastcall AnimShowForm(Sskinprovider::TsSkinProvider* sp, System::Word wTime = (System::Word)(0x0), int MaxTransparency = 0xff, Sconst::TacAnimType AnimType = (Sconst::TacAnimType)(0x1));
extern PACKAGE void __fastcall AnimHideForm(System::TObject* SkinProvider);
extern PACKAGE void __fastcall PrintDlgClient(Acdials::TacDialogWnd* ListSW, Vcl::Graphics::TBitmap* acDstBmp, bool CopyScreen = false);
extern PACKAGE void __fastcall AnimHideDlg(Acdials::TacDialogWnd* ListSW);
extern PACKAGE void __fastcall AnimShowDlg(Acdials::TacDialogWnd* ListSW, System::Word wTime = (System::Word)(0x0), int MaxTransparency = 0xff, Sconst::TacAnimType AnimType = (Sconst::TacAnimType)(0x1));
extern PACKAGE void __fastcall PrepareForAnimation(Vcl::Controls::TWinControl* Ctrl);
extern PACKAGE void __fastcall AnimShowControl(Vcl::Controls::TWinControl* Ctrl, System::Word wTime = (System::Word)(0x0), int MaxTransparency = 0xff, Sconst::TacAnimType AnimType = (Sconst::TacAnimType)(0x0));
extern PACKAGE void __fastcall SetParentUpdated(Vcl::Controls::TWinControl* wc)/* overload */;
extern PACKAGE void __fastcall SetParentUpdated(HWND pHwnd)/* overload */;
extern PACKAGE System::Uitypes::TColor __fastcall GetControlColor(Vcl::Controls::TControl* Control)/* overload */;
extern PACKAGE System::Uitypes::TColor __fastcall GetControlColor(unsigned Handle)/* overload */;
extern PACKAGE bool __fastcall AllEditSelected(Vcl::Stdctrls::TCustomEdit* Ctrl);
extern PACKAGE void __fastcall PaintControls(HDC DC, Vcl::Controls::TWinControl* OwnerControl, bool ChangeCache, const System::Types::TPoint &Offset, unsigned AHandle = (unsigned)(0x0), bool CheckVisible = true);
extern PACKAGE int __fastcall SendAMessage(HWND Handle, int Cmd, int LParam = (int)(0x0))/* overload */;
extern PACKAGE int __fastcall SendAMessage(Vcl::Controls::TControl* Control, int Cmd, int LParam = (int)(0x0))/* overload */;
extern PACKAGE void __fastcall SetBoolMsg(HWND Handle, unsigned Cmd, bool Value);
extern PACKAGE bool __fastcall GetBoolMsg(Vcl::Controls::TWinControl* Control, unsigned Cmd)/* overload */;
extern PACKAGE bool __fastcall GetBoolMsg(HWND CtrlHandle, unsigned Cmd)/* overload */;
extern PACKAGE bool __fastcall ControlIsReady(Vcl::Controls::TControl* Control);
extern PACKAGE Vcl::Forms::TCustomForm* __fastcall GetOwnerForm(System::Classes::TComponent* Component);
extern PACKAGE Vcl::Forms::TCustomFrame* __fastcall GetOwnerFrame(System::Classes::TComponent* Component);
extern PACKAGE void __fastcall SetControlsEnabled(Vcl::Controls::TWinControl* Parent, bool Value);
extern PACKAGE int __fastcall GetStringFlags(Vcl::Controls::TControl* Control, System::Classes::TAlignment al);
extern PACKAGE void __fastcall RepaintsControls(Vcl::Controls::TWinControl* Owner, bool BGChanged);
extern PACKAGE void __fastcall AlphaBroadCast(Vcl::Controls::TWinControl* Control, void *Message)/* overload */;
extern PACKAGE void __fastcall AlphaBroadCast(HWND Handle, void *Message)/* overload */;
extern PACKAGE int __fastcall GetCtrlRange(Vcl::Controls::TWinControl* Ctl, int nBar);
extern PACKAGE System::Types::TRect __fastcall ACClientRect(HWND Handle);
extern PACKAGE void __fastcall TrySetSkinSection(Vcl::Controls::TControl* Control, const System::UnicodeString SectionName);
extern PACKAGE int __fastcall GetAlignShift(Vcl::Controls::TWinControl* Ctrl, Vcl::Controls::TAlign Align, bool GraphCtrlsToo = false);
extern PACKAGE HWND __fastcall GetParentFormHandle(const HWND CtrlHandle);

}	/* namespace Svclutils */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_SVCLUTILS)
using namespace Svclutils;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SvclutilsHPP
