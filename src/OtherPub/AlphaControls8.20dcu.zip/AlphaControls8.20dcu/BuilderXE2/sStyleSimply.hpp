// CodeGear C++Builder
// Copyright (c) 1995, 2011 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sStyleSimply.pas' rev: 23.00 (Win32)

#ifndef SstylesimplyHPP
#define SstylesimplyHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Winapi.Windows.hpp>	// Pascal unit
#include <Vcl.Graphics.hpp>	// Pascal unit
#include <System.Classes.hpp>	// Pascal unit
#include <Vcl.Controls.hpp>	// Pascal unit
#include <acntUtils.hpp>	// Pascal unit
#include <System.SysUtils.hpp>	// Pascal unit
#include <Vcl.StdCtrls.hpp>	// Pascal unit
#include <Vcl.Dialogs.hpp>	// Pascal unit
#include <Vcl.Forms.hpp>	// Pascal unit
#include <Winapi.Messages.hpp>	// Pascal unit
#include <sConst.hpp>	// Pascal unit
#include <Vcl.ExtCtrls.hpp>	// Pascal unit
#include <System.IniFiles.hpp>	// Pascal unit
#include <System.UITypes.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sstylesimply
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsSkinData;
class PASCALIMPLEMENTATION TsSkinData : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	System::UnicodeString SkinPath;
	bool Active;
	double Version;
	System::UnicodeString Author;
	System::UnicodeString Description;
	System::Uitypes::TColor Shadow1Color;
	short Shadow1Offset;
	short Shadow1Blur;
	short Shadow1Transparency;
	short ExBorderWidth;
	short ExTitleHeight;
	short ExMaxHeight;
	short ExContentOffs;
	short ExShadowOffs;
	short ExCenterOffs;
	short ExDrawMode;
	System::Uitypes::TColor FXColor;
	System::Uitypes::TColor BorderColor;
	short BISpacing;
	short BIVAlign;
	short BIRightMargin;
	short BILeftMargin;
	short BITopMargin;
	short BIKeepHUE;
	short BICloseGlow;
	short BICloseGlowMargin;
	short BIMaxGlow;
	short BIMaxGlowMargin;
	short BIMinGlow;
	short BIMinGlowMargin;
	bool UseAeroBluring;
	System::Uitypes::TColor ExtShadowColor;
	__fastcall virtual ~TsSkinData(void);
public:
	/* TObject.Create */ inline __fastcall TsSkinData(void) : System::TObject() { }
	
};


struct DECLSPEC_DRECORD TConstantSkinData
{
	
public:
	short IndexGLobalInfo;
	short ExBorder;
	short IndexTabTop;
	short IndexTabBottom;
	short IndexTabLeft;
	short IndexTabRight;
	short MaskTabTop;
	short MaskTabBottom;
	short MaskTabLeft;
	short MaskTabRight;
	short IndexScrollTop;
	short IndexScrollBottom;
	short IndexScrollLeft;
	short IndexScrollRight;
	short MaskScrollTop;
	short MaskScrollBottom;
	short MaskScrollLeft;
	short MaskScrollRight;
	short IndexBGScrollTop;
	short IndexBGScrollBottom;
	short IndexBGScrollLeft;
	short IndexBGScrollRight;
	short IndexBGHotScrollTop;
	short IndexBGHotScrollBottom;
	short IndexBGHotScrollLeft;
	short IndexBGHotScrollRight;
	short MaskCloseBtn;
	short MaskCloseAloneBtn;
	short MaskMaxBtn;
	short MaskNormBtn;
	short MaskMinBtn;
	short MaskHelpBtn;
	short MaskCloseSmall;
	short MaskMaxSmall;
	short MaskNormSmall;
	short MaskMinSmall;
	short MaskHelpSmall;
	short MaskArrowTop;
	short MaskArrowBottom;
	short MaskArrowLeft;
	short MaskArrowRight;
	short IndexSliderVert;
	short IndexSliderHorz;
	short MaskSliderVert;
	short MaskSliderHorz;
	short MaskSliderGlyphVert;
	short MaskSliderGlyphHorz;
	short ScrollSliderBGHorz;
	short ScrollSliderBGHotHorz;
	short ScrollSliderBGVert;
	short ScrollSliderBGHotVert;
	short IndexScrollBar1H;
	short IndexScrollBar1V;
	short IndexScrollBar2H;
	short IndexScrollBar2V;
	short MaskScrollBar1H;
	short MaskScrollBar1V;
	short MaskScrollBar2H;
	short MaskScrollBar2V;
	short BGScrollBar1H;
	short BGScrollBar1V;
	short BGScrollBar2H;
	short BGScrollBar2V;
	short BGHotScrollBar1H;
	short BGHotScrollBar1V;
	short BGHotScrollBar2H;
	short BGHotScrollBar2V;
	short CheckBoxChecked;
	short CheckBoxUnChecked;
	short CheckBoxGrayed;
	short RadioButtonChecked;
	short RadioButtonUnChecked;
	short RadioButtonGrayed;
	short SmallCheckBoxChecked;
	short SmallCheckBoxUnChecked;
	short SmallCheckBoxGrayed;
	int ComboBtnIndex;
	int ComboBtnBorder;
	int ComboBtnBG;
	int ComboBtnBGHot;
	int ComboGlyph;
	int GripRightBottom;
	int GripHorizontal;
	int GripVertical;
	int IndexWebBtn;
};


typedef System::DynamicArray<System::Classes::TComponent*> Sstylesimply__2;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::UnicodeString GlobalSectionName;
extern PACKAGE Vcl::Graphics::TIcon* AppIcon;
extern PACKAGE Vcl::Graphics::TIcon* AppIconLarge;
extern PACKAGE bool aSkinChanging;
extern PACKAGE Sstylesimply__2 HookedComponents;
extern PACKAGE void __fastcall CopyExForms(System::Classes::TComponent* SkinManager);
extern PACKAGE void __fastcall LockForms(System::Classes::TComponent* SkinManager);
extern PACKAGE void __fastcall UnLockForms(System::Classes::TComponent* SkinManager, bool Repaint = true);
extern PACKAGE void __fastcall AppBroadCastS(void *Message);
extern PACKAGE void __fastcall SendToHooked(void *Message);
extern PACKAGE void __fastcall IntSkinForm(Vcl::Forms::TCustomForm* Form);
extern PACKAGE void __fastcall IntUnSkinForm(Vcl::Forms::TCustomForm* Form);

}	/* namespace Sstylesimply */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_SSTYLESIMPLY)
using namespace Sstylesimply;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SstylesimplyHPP
