// CodeGear C++Builder
// Copyright (c) 1995, 2011 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sMaskData.pas' rev: 23.00 (Win32)

#ifndef SmaskdataHPP
#define SmaskdataHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Winapi.Windows.hpp>	// Pascal unit
#include <Vcl.Graphics.hpp>	// Pascal unit
#include <sConst.hpp>	// Pascal unit
#include <Vcl.Imaging.jpeg.hpp>	// Pascal unit
#include <System.Types.hpp>	// Pascal unit
#include <System.UITypes.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Smaskdata
{
//-- type declarations -------------------------------------------------------
struct DECLSPEC_DRECORD TsMaskData
{
	
public:
	Vcl::Graphics::TBitmap* Bmp;
	System::UnicodeString ClassName;
	System::UnicodeString PropertyName;
	System::Types::TRect R;
	short ImageCount;
	short MaskType;
	short BorderWidth;
	short DrawMode;
	Sconst::TacImgType ImgType;
	System::TObject* Manager;
	short WL;
	short WT;
	short WR;
	short WB;
	short CornerType;
};


typedef TsMaskData *PsMaskData;

struct DECLSPEC_DRECORD TsPatternData
{
	
public:
	Vcl::Imaging::Jpeg::TJPEGImage* Img;
	System::UnicodeString ClassName;
	System::UnicodeString PropertyName;
};


struct DECLSPEC_DRECORD TsFontColor
{
	
public:
	System::Uitypes::TColor Color;
	System::Uitypes::TColor Left;
	System::Uitypes::TColor Top;
	System::Uitypes::TColor Right;
	System::Uitypes::TColor Bottom;
};


struct DECLSPEC_DRECORD TsGenState
{
	
public:
	System::Uitypes::TColor Color;
	TsFontColor FontColor;
	int GradientPercent;
	System::UnicodeString GradientData;
	Sconst::TsGradArray GradientArray;
	int ImagePercent;
	int TextureIndex;
	System::Uitypes::TColor GlowColor;
	System::Byte GlowSize;
	int Transparency;
};


typedef System::StaticArray<TsGenState, 2> TsProps;

struct DECLSPEC_DRECORD TsGeneralData
{
	
public:
	System::UnicodeString ParentClass;
	System::UnicodeString ClassName;
	int States;
	TsProps Props;
	bool GiveOwnFont;
	bool ReservedBoolean;
	bool ShowFocus;
	int GlowCount;
	int GlowMargin;
	int BorderIndex;
	int ImgTL;
	int ImgTR;
	int ImgBL;
	int ImgBR;
	int TextureNormal;
	System::Uitypes::TColor Color;
	int Transparency;
	int GradientPercent;
	System::UnicodeString GradientData;
	Sconst::TsGradArray GradientArray;
	int ImagePercent;
	System::StaticArray<int, 5> FontColor;
	System::Uitypes::TColor HotColor;
	int HotTransparency;
	int HotGradientPercent;
	System::UnicodeString HotGradientData;
	Sconst::TsGradArray HotGradientArray;
	int HotImagePercent;
	System::StaticArray<int, 5> HotFontColor;
	bool FadingEnabled;
	int FadingIterations;
	System::Uitypes::TColor HotGlowColor;
	System::Uitypes::TColor GlowColor;
	System::Byte HotGlowSize;
	System::Byte GlowSize;
};


typedef System::DynamicArray<TsMaskData> TsMaskArray;

typedef System::DynamicArray<TsPatternData> TsPatternArray;

typedef System::DynamicArray<TsGeneralData> TsGeneralDataArray;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE int __fastcall WidthOfImage(const TsMaskData &md);
extern PACKAGE int __fastcall HeightOfImage(const TsMaskData &md);

}	/* namespace Smaskdata */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_SMASKDATA)
using namespace Smaskdata;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SmaskdataHPP
