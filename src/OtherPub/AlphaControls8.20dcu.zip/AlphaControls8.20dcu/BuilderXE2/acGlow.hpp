// CodeGear C++Builder
// Copyright (c) 1995, 2011 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'acGlow.pas' rev: 23.00 (Win32)

#ifndef AcglowHPP
#define AcglowHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Winapi.Windows.hpp>	// Pascal unit
#include <Vcl.Controls.hpp>	// Pascal unit
#include <System.Classes.hpp>	// Pascal unit
#include <Vcl.Forms.hpp>	// Pascal unit
#include <System.Types.hpp>	// Pascal unit
#include <System.SysUtils.hpp>	// Pascal unit
#include <Vcl.Graphics.hpp>	// Pascal unit
#include <sSkinManager.hpp>	// Pascal unit
#include <Winapi.Messages.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Acglow
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TacGlowEffect;
class PASCALIMPLEMENTATION TacGlowEffect : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	Sskinmanager::TsSkinManager* SkinManager;
	int MaskIndex;
	int Margin;
	Vcl::Forms::TForm* Wnd;
	Vcl::Graphics::TBitmap* AlphaBmp;
	System::Classes::TWndMethod OldWndProc;
	__fastcall virtual TacGlowEffect(void);
	virtual void __fastcall CreateAlphaBmp(const int Width, const int Height);
	__fastcall virtual ~TacGlowEffect(void);
	int __fastcall IntBorderWidth(void);
	void __fastcall Show(const System::Types::TRect &R, const System::Types::TRect &RealRect, const int Alpha, HWND WndHandle);
	void __fastcall NewWndProc(Winapi::Messages::TMessage &Message);
};


typedef System::DynamicArray<TacGlowEffect*> TacGlowEffects;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE bool bGlowingDestroying;
extern PACKAGE int __fastcall ShowGlow(const System::Types::TRect &R, const System::Types::TRect &RealRect, const System::UnicodeString SkinSection, const System::UnicodeString Name, const int Margin, const int Alpha, HWND WndHandle, Sskinmanager::TsSkinManager* SkinManager = (Sskinmanager::TsSkinManager*)(0x0));
extern PACKAGE void __fastcall HideGlow(int &ID);
extern PACKAGE void __fastcall ClearGlows(bool ManualFreeing = false);

}	/* namespace Acglow */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_ACGLOW)
using namespace Acglow;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AcglowHPP
