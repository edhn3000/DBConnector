// CodeGear C++Builder
// Copyright (c) 1995, 2007 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Sdefaults.pas' rev: 11.00

#ifndef SdefaultsHPP
#define SdefaultsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sconst.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sdefaults
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TacThirdPartyTypes { tpEdit, tpButton, tpBitBtn, tpCheckBox, tpComboBox, tpGrid, tpGroupBox, tpListView, tpPanel, tpTreeView, tpwwEdit, tpGridEh, tpVirtualTree, tpPageControl, tpTabControl, tpToolBar, tpStatusBar, tpSpeedButton, tpScrollControl, tpUpDownBtn, tpScrollBar };
#pragma option pop

typedef AnsiString sDefaults__1[21];

typedef AnsiString sDefaults__2[21];

//-- var, const, procedure ---------------------------------------------------
static const TacThirdPartyTypes acLastSupportedType = (TacThirdPartyTypes)(20);
static const char sl_Third_Edit = '\x20';
static const char sl_Third_Panel = '\x20';
#define sl_Third_Button "TButton"
static const char sl_Third_BitBtn = '\x20';
static const char sl_Third_CheckBox = '\x20';
static const char sl_Third_GroupBox = '\x20';
static const char sl_Third_Grid = '\x20';
static const char sl_Third_TreeView = '\x20';
static const char sl_Third_ComboBox = '\x20';
static const char sl_Third_ListView = '\x20';
static const char sl_Third_WWEdit = '\x20';
static const char sl_Third_GridEH = '\x20';
static const char sl_Third_VirtualTree = '\x20';
static const char sl_Third_PageControl = '\x20';
static const char sl_Third_TabControl = '\x20';
static const char sl_Third_ToolBar = '\x20';
static const char sl_Third_StatusBar = '\x20';
static const char sl_Third_SpeedButton = '\x20';
static const char sl_Third_ScrollControl = '\x20';
static const char sl_Third_UpDownBtn = '\x20';
static const char sl_Third_ScrollBar = '\x20';
static const char sl_Third_WebBrowser = '\x20';
extern PACKAGE AnsiString acThirdNames[21];
extern PACKAGE AnsiString acThirdCaptions[21];
#define DefSkinsDir "c:\\Skins"
static const Shortint DefNumGlyphs = 0x1;
#define DefDisabledGlyphKind (Set<Sconst::sConst__3, Sconst::dgBlended, Sconst::dgGrayed> () << Sconst::dgBlended )
#define DefDisabledKind (Set<Sconst::sConst__4, Sconst::dkBlended, Sconst::dkGrayed> () << Sconst::dkBlended )
#define DefDisabledBlend  (4.000000E-01)
static const bool DefMakeSkinMenu = false;
static const Shortint DefGlyphBlend = 0x0;
#define DefWeekends (Set<Comctrls::TCalDayOfWeek, Comctrls::dowMonday, Comctrls::dowLocaleDefault> () << Comctrls::dowSunday )
static const bool ChangeFormsInDesign = false;

}	/* namespace Sdefaults */
using namespace Sdefaults;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Sdefaults
