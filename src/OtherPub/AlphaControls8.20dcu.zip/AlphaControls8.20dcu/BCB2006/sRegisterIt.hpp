// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Sregisterit.pas' rev: 10.00

#ifndef SregisteritHPP
#define SregisteritHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sscrollbar.hpp>	// Pascal unit
#include <Slabel.hpp>	// Pascal unit
#include <Sbutton.hpp>	// Pascal unit
#include <Sbitbtn.hpp>	// Pascal unit
#include <Sspeedbutton.hpp>	// Pascal unit
#include <Spanel.hpp>	// Pascal unit
#include <Slistbox.hpp>	// Pascal unit
#include <Actitlebar.hpp>	// Pascal unit
#include <Shintmanager.hpp>	// Pascal unit
#include <Stoolbar.hpp>	// Pascal unit
#include <Scolorselect.hpp>	// Pascal unit
#include <Sdialogs.hpp>	// Pascal unit
#include <Scurrencyedit.hpp>	// Pascal unit
#include <Sspinedit.hpp>	// Pascal unit
#include <Sradiobutton.hpp>	// Pascal unit
#include <Scomboedit.hpp>	// Pascal unit
#include <Spagecontrol.hpp>	// Pascal unit
#include <Scurredit.hpp>	// Pascal unit
#include <Stooledit.hpp>	// Pascal unit
#include <Smonthcalendar.hpp>	// Pascal unit
#include <Sbevel.hpp>	// Pascal unit
#include <Sgroupbox.hpp>	// Pascal unit
#include <Sstatusbar.hpp>	// Pascal unit
#include <Strackbar.hpp>	// Pascal unit
#include <Scalculator.hpp>	// Pascal unit
#include <Smaskedit.hpp>	// Pascal unit
#include <Scomboboxes.hpp>	// Pascal unit
#include <Ssplitter.hpp>	// Pascal unit
#include <Stabcontrol.hpp>	// Pascal unit
#include <Sfontctrls.hpp>	// Pascal unit
#include <Sscrollbox.hpp>	// Pascal unit
#include <Srichedit.hpp>	// Pascal unit
#include <Sfilectrl.hpp>	// Pascal unit
#include <Streeview.hpp>	// Pascal unit
#include <Sframeadapter.hpp>	// Pascal unit
#include <Supdown.hpp>	// Pascal unit
#include <Sframebar.hpp>	// Pascal unit
#include <Acshellctrls.hpp>	// Pascal unit
#include <Accoolbar.hpp>	// Pascal unit
#include <Acprogressbar.hpp>	// Pascal unit
#include <Acnotebook.hpp>	// Pascal unit
#include <Acalphahints.hpp>	// Pascal unit
#include <Acheadercontrol.hpp>	// Pascal unit
#include <Acmagn.hpp>	// Pascal unit
#include <Slistview.hpp>	// Pascal unit
#include <Sgauge.hpp>	// Pascal unit
#include <Sedit.hpp>	// Pascal unit
#include <Sskinmanager.hpp>	// Pascal unit
#include <Sskinprovider.hpp>	// Pascal unit
#include <Scombobox.hpp>	// Pascal unit
#include <Scheckbox.hpp>	// Pascal unit
#include <Acalphaimagelist.hpp>	// Pascal unit
#include <Smemo.hpp>	// Pascal unit
#include <Schecklistbox.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sregisterit
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Sregisterit */
using namespace Sregisterit;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Sregisterit
