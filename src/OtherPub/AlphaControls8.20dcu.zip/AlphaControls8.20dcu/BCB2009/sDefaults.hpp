// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Sdefaults.pas' rev: 20.00

#ifndef SdefaultsHPP
#define SdefaultsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sconst.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sdefaults
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TacThirdPartyTypes { tpEdit, tpButton, tpBitBtn, tpCheckBox, tpComboBox, tpGrid, tpGroupBox, tpListView, tpPanel, tpTreeView, tpwwEdit, tpGridEh, tpVirtualTree, tpPageControl, tpTabControl, tpToolBar, tpStatusBar, tpSpeedButton, tpScrollControl, tpUpDownBtn, tpScrollBar };
#pragma option pop

typedef StaticArray<System::UnicodeString, 21> Sdefaults__1;

typedef StaticArray<System::UnicodeString, 21> Sdefaults__2;

//-- var, const, procedure ---------------------------------------------------
static const TacThirdPartyTypes acLastSupportedType = (TacThirdPartyTypes)(20);
static const WideChar sl_Third_Edit = (WideChar)(0x20);
static const WideChar sl_Third_Panel = (WideChar)(0x20);
#define sl_Third_Button L"TButton"
static const WideChar sl_Third_BitBtn = (WideChar)(0x20);
static const WideChar sl_Third_CheckBox = (WideChar)(0x20);
static const WideChar sl_Third_GroupBox = (WideChar)(0x20);
static const WideChar sl_Third_Grid = (WideChar)(0x20);
static const WideChar sl_Third_TreeView = (WideChar)(0x20);
static const WideChar sl_Third_ComboBox = (WideChar)(0x20);
static const WideChar sl_Third_ListView = (WideChar)(0x20);
static const WideChar sl_Third_WWEdit = (WideChar)(0x20);
static const WideChar sl_Third_GridEH = (WideChar)(0x20);
static const WideChar sl_Third_VirtualTree = (WideChar)(0x20);
static const WideChar sl_Third_PageControl = (WideChar)(0x20);
static const WideChar sl_Third_TabControl = (WideChar)(0x20);
static const WideChar sl_Third_ToolBar = (WideChar)(0x20);
static const WideChar sl_Third_StatusBar = (WideChar)(0x20);
static const WideChar sl_Third_SpeedButton = (WideChar)(0x20);
static const WideChar sl_Third_ScrollControl = (WideChar)(0x20);
static const WideChar sl_Third_UpDownBtn = (WideChar)(0x20);
static const WideChar sl_Third_ScrollBar = (WideChar)(0x20);
static const WideChar sl_Third_WebBrowser = (WideChar)(0x20);
extern PACKAGE Sdefaults__1 acThirdNames;
extern PACKAGE Sdefaults__2 acThirdCaptions;
#define DefSkinsDir L"c:\\Skins"
static const ShortInt DefNumGlyphs = 0x1;
#define DefDisabledGlyphKind (Set<Sconst::Sconst__3, dgBlended, dgGrayed> () << dgBlended )
#define DefDisabledKind (Set<Sconst::Sconst__4, dkBlended, dkGrayed> () << dkBlended )
#define DefDisabledBlend  (4.000000E-01)
static const bool DefMakeSkinMenu = false;
static const ShortInt DefGlyphBlend = 0x0;
#define DefWeekends (Set<Comctrls::TCalDayOfWeek, dowMonday, dowLocaleDefault> () << dowSunday )
static const bool ChangeFormsInDesign = false;

}	/* namespace Sdefaults */
using namespace Sdefaults;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SdefaultsHPP
