SynAutoCorrectDemo.dpr
----------------------

- Needs Delphi 2 or higher
- Shows how to use the SynAutoCorrect component.
