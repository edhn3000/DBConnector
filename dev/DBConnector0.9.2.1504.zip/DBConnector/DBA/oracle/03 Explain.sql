-- ִ�мƻ�                            
-- NotRun
-- NotOpenTab
explain plan for /*sql here*/;
select * from table(dbms_xplan.display());
