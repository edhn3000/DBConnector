Create Table aaa(
  N_XH  Int,        
  C_JD1 Varchar(50),
  C_JD2 Varchar(50),
  C_JD2 Varchar(50),
  C_JD3 Varchar(50),
  C_JD4 Varchar(50) 
);

